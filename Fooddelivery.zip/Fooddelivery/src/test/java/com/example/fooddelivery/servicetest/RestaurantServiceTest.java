package com.example.fooddelivery.servicetest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.fooddelivery.dto.RestaurantDTO;
import com.example.fooddelivery.model.Restaurant;
import com.example.fooddelivery.repository.RestaurantDAO;
import com.example.fooddelivery.service.RestaurantService;


@ExtendWith(MockitoExtension.class)
public class RestaurantServiceTest {

	@InjectMocks
	RestaurantService service;
	
	@Mock
	RestaurantDAO dao;
	RestaurantDTO dto;
	Restaurant res;
	
	List<Restaurant> resList;
	
	
	@BeforeEach
	public void setUp() {
		res = new Restaurant(1, "CTR", "ctr@gmail.com", "9415482675", "Malleshwaram");
		
		dto = new RestaurantDTO(1, "CTR", "ctr@gmail.com", "9415482675", "Malleshwaram");
		resList = new ArrayList<Restaurant>();
		resList.add(res);
	}
	
	// create Restaurant
		@Test
		public void createRestaurantTest() {
			String exp="Restaurant Details Created Successfully";
		 String act =service.createRestaurant(dto);
		 assertEquals(exp, act);
			
		}
		
	// get all Restaurant
		@Test
		public void getAllRestaurantTest() {
			when(dao.findAll()).thenReturn(resList);
			 List<Restaurant> actList=  service.getAllRestaurant();
			 assertEquals(resList, actList );
			 assertNotNull(actList);
		}
		
	// get Restaurant by id
		@Test
		public void getByIdTest() {
			int id=1;
	        
			Optional<Restaurant> expRestaurant = Optional.of(res);
	        when(dao.findById(id)).thenReturn(expRestaurant);
	        Optional<Restaurant> actRestaurant = service.getById(id);
	        assertEquals(expRestaurant, actRestaurant);
	        verify(dao).findById(id);
		}
	
	// delete Restaurant by id
		@Test
		public void deleteByIdTest() {
		    int id = 1;
		    String exp ="Restaurant Details Deleted Successfully";
		    when(dao.findById(id)).thenReturn(Optional.of(res));
		    String act = service.deleteById(id);
		    assertEquals(exp, act);
		    verify(dao).deleteById(id);
		}
		@Test
		public void dleteByIdTest1() {
			int id=1;
			String exp= "Restaurant id not found";
			when(dao.findById(id)).thenReturn(Optional.empty());
			String act = service.deleteById(id);
			assertEquals(exp, act);
		}
		
	// update user by id
		
		@Test
		public void userRestaurantTestIf	() {
			int id=1;
			String exp= "data not found";
			when(dao.findById(id)).thenReturn(Optional.empty());
			String act = service.updateRestaurant(dto,id);
			assertEquals(exp, act);
		}
		
		
		@Test
		public void updateRestaurantTestElse() {
			int id=1;
			when(dao.findById(id)).thenReturn(Optional.of(res));
			String list = service.updateRestaurant(dto,id);
			assertNotNull(list);
		}
}


















