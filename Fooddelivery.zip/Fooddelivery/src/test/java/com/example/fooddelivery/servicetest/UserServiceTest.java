package com.example.fooddelivery.servicetest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.fooddelivery.dto.UserDTO;
import com.example.fooddelivery.model.User;
import com.example.fooddelivery.repository.UserDAO;
import com.example.fooddelivery.service.UserService;


@ExtendWith(MockitoExtension.class)
public class UserServiceTest {
	@InjectMocks
	UserService service;
	
	@Mock
	UserDAO dao;
	
	UserDTO dto;
	
	User ur;
	 
	List<User> userList;
	
	
	@BeforeEach
	public void userTest() {
		 ur = new User(1, "Hanumantha","Hanu@2109", "tphanumantha@gmail.com", "9113583889", "Davanagere");
		
		dto = new UserDTO(1, "Hanumantha","Hanu@2109", "tphanumantha@gmail.com", "9113583889", "Davanagere");
		userList= new ArrayList<User>();
		userList.add(ur);
		
	}
// create user
	@Test
	public void creatUserTest() {
		String exp="User Details Created Successfully";
	 String act =service.createUser(dto);
	 assertEquals(exp, act);
		
	}
	
// get all user
	@Test
	public void getAllUserTest() {
		when(dao.findAll()).thenReturn(userList);
		 List<User> actList=  service.getAllUser();
		 assertEquals(userList, actList );
		 assertNotNull(actList);
	}
	
// get user by id
	@Test
	public void getByIdTest() {
		int id=1;
        
		Optional<User> expectedUser = Optional.of(ur);
        when(dao.findById(id)).thenReturn(expectedUser);
        Optional<User> actualUser = service.getById(id);
        assertEquals(expectedUser, actualUser);
        verify(dao).findById(id);
	}
	
// delete user by id
	@Test
	public void deleteByIdTest() {
	    int id = 1;
	    String exp ="User Details Deleted Successfully";
	    when(dao.findById(id)).thenReturn(Optional.of(ur));
	    String act = service.deleteById(id);
	    assertEquals(exp, act);
	    verify(dao).deleteById(id);
	}
	@Test
	public void dleteByIdTest1() {
		int id=1;
		String exp= "User id not found";
		when(dao.findById(id)).thenReturn(Optional.empty());
		String act = service.deleteById(id);
		assertEquals(exp, act);
	}
	
// update user by id
	
	@Test
	public void userUpdateTestIf	() {
		int id=1;
		String exp= "data not found";
		when(dao.findById(id)).thenReturn(Optional.empty());
		String act = service.updateUser(dto,id);
		assertEquals(exp, act);
	}
	
	
	@Test
	public void updateUserTestElse() {
		int id=1;
		when(dao.findById(id)).thenReturn(Optional.of(ur));
		String list = service.updateUser(dto,id);
		assertNotNull(list);
	}
}
