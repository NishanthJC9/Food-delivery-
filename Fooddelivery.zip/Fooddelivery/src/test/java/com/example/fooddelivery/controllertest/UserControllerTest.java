package com.example.fooddelivery.controllertest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.fooddelivery.controller.UserController;
import com.example.fooddelivery.dto.UserDTO;
import com.example.fooddelivery.exceptionhandling.MyDeleteException;
import com.example.fooddelivery.exceptionhandling.MyUserexception;
import com.example.fooddelivery.model.User;
import com.example.fooddelivery.service.UserService;

@ExtendWith(MockitoExtension.class)
public class UserControllerTest {

	@InjectMocks
	UserController control;
	
	@Mock
	UserService service;
	UserDTO dto;
	User usr1 , usr2;
	

	@BeforeEach
	public void setup() {
	dto = new UserDTO(1, "Hanumantha","Hanu@2109", "tphanumantha@gmail.com", "9113583889", "Davanagere");
	usr1= new User(1, "Hanumantha","Hanu@2109", "tphanumantha@gmail.com", "9113583889", "Davanagere");
	usr2 = new User(0, "kjh", "kjhg@bcbc", "mkjhlj@bhg.com", "8465213544", "kjfhge");
	
	}
	
// crate user
	@Test
	public void createUserTest() {
		String expResult="User Details Created Successfully";// expected result
		UserDTO dto = new UserDTO();// dto object to pass onto the testing method
		when(service.createUser(dto)).thenReturn(expResult);// Testing method
		String actResult = control.createUser(dto);// Calling actual method from control class
		assertEquals(expResult, actResult);
	}
	
//	get all user
	@Test
    public void getAllUserTest() {
        List<User> expectedUsers = Arrays.asList(usr1, usr2);
        when(service.getAllUser()).thenReturn(expectedUsers);
        List<User> actualUsers = control.getAllUser();
        assertEquals(expectedUsers, actualUsers);
        verify(service).getAllUser();
    }
	
// get user by id
	@Test
	public void getByIdTest_ValidId() throws MyUserexception {
		int id = 1;
        Optional<User> expectedUser = Optional.of(usr1);
        when(service.getById(id)).thenReturn(expectedUser);
        Optional<User> actualUser = control.getById(id);
        assertEquals(expectedUser, actualUser);
        verify(service).getById(id);	
	}

	@Test
	public void getByIdTest_InvalidId() {
		// Given
        int userid = 0;
        
     // When/Then
        MyUserexception exception = assertThrows(MyUserexception.class, () -> {
            control.getById(userid);
        });
        assertEquals("userid should be greater than Zero(0)", exception.getMessage());
	}
	
// delete user by id
	@Test
	public void deleteByIdTest_ValidId () throws MyDeleteException {
		int id = 1;
		String expectedResult = "User Deleted Successfully";
		when(service.deleteById(id)).thenReturn(expectedResult);
		String actualResult = control.deleteById(id);
		assertEquals(expectedResult, actualResult);
		verify(service).deleteById(id);
	}
	
	@Test
	public void deleteByIdTest_InvalidId() {
		int id = 0;
		
		MyDeleteException deleteExp = assertThrows(MyDeleteException.class, () -> {
            control.deleteById(id);
        });
        assertEquals("To delete User userid should be greater than Zero(0)", deleteExp.getMessage());
	}
	
// update user by id
	@Test
	public void updateUserTest() {
		 // Given
	    int id = 1;
	    UserDTO userDto = new UserDTO();
	    String expectedResult = "User Details Updated Successfully";
	    when(service.updateUser(userDto, id)).thenReturn(expectedResult);
	    String actualResult = control.updateUser(userDto, id);
	    assertEquals(expectedResult, actualResult);
	    verify(service).updateUser(userDto, id);
	}
}
