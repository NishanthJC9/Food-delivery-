package com.example.fooddelivery.controllertest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.fooddelivery.controller.RestaurantController;
import com.example.fooddelivery.dto.RestaurantDTO;
import com.example.fooddelivery.exceptionhandling.MyDeleteException;
import com.example.fooddelivery.exceptionhandling.MyUserexception;
import com.example.fooddelivery.model.Restaurant;
import com.example.fooddelivery.service.RestaurantService;

@ExtendWith(MockitoExtension.class)
public class RestaurantControllerTest {

	@InjectMocks
	RestaurantController control;
	
	@Mock
	RestaurantService service;
	RestaurantDTO dto;
	Restaurant res1, res2;
	
	@BeforeEach
	public void setup() {
		dto = new RestaurantDTO(1, "CTR", "ctr@gmail.com", "9415482675", "Malleshwaram");
		res1 = new Restaurant(1, "CTR", "ctr@gmail.com", "9415482675", "Malleshwaram");
		res2 = new Restaurant(2, "Rameshwaram Cafe", "rameshwaram@gmail.com", "9475114452", "JP Nagar");
	}
	
	// create Restaurant
	@Test
	public void createRestaurant() {
		String expResult = "Restaurant Details Created Successfully";
		RestaurantDTO dto = new RestaurantDTO();
		when(service.createRestaurant(dto)).thenReturn(expResult);
		String actResult = control.createRestaurant(dto);
		assertEquals(expResult, actResult);
	}
	 
//	get all Restaurant
	@Test
    public void getAllRestaurantTest() {
        List<Restaurant> expResult = Arrays.asList(res1, res2);
        when(service.getAllRestaurant()).thenReturn(expResult);
        List<Restaurant> actResult = control.getAllRestaurant();
        assertEquals(expResult, actResult);
        verify(service).getAllRestaurant();
    }
	
	
	// get Restaurant by id
		@Test
		public void getByIdTest_ValidId() throws MyUserexception {
			int id = 1;
	        Optional<Restaurant> expResult = Optional.of(res1);
	        when(service.getById(id)).thenReturn(expResult);
	        Optional<Restaurant> actResult = control.getById(id);
	        assertEquals(expResult, actResult);
	        verify(service).getById(id);	
		}

		@Test
		public void getByIdTest_InvalidId() {
			// Given
	        int resid = 0;
	        
	        // When/Then
	        MyUserexception exception = assertThrows(MyUserexception.class, () -> {
	            control.getById(resid);
	        });
	        assertEquals("restaurantid should be greater than Zero(0)", exception.getMessage());
		}
	
		
// delete Restaurant by id
		@Test
		public void deleteByIdTest_ValidId () throws MyDeleteException {
			int id = 1;
			String expResult = "Restaurant Details Deleted Successfully";
			when(service.deleteById(id)).thenReturn(expResult);
			String actResult = control.deleteById(id);
			assertEquals(expResult, actResult);
			verify(service).deleteById(id);
		}
		
		@Test
		public void deleteByIdTest_InvalidId() {
			int id = 0;
			
			MyDeleteException deleteExp = assertThrows(MyDeleteException.class, () -> {
	            control.deleteById(id);
	        });
	        assertEquals("To delete Restaurant restaurantid should be greater than Zero(0)", deleteExp.getMessage());
		}
		
		
// update Restaurant by id
		@Test
		public void updateRestaurantTest() {
			 // Given
		    int id = 1;
		    RestaurantDTO resDto = new RestaurantDTO();
		    String expResult = "Restaurant Details Updated Successfully";
		    when(service.updateRestaurant(resDto, id)).thenReturn(expResult);
		    String actResult = control.updateRestaurant(resDto, id);
		    assertEquals(expResult, actResult);
		    verify(service).updateRestaurant(resDto, id);
		}
}
















