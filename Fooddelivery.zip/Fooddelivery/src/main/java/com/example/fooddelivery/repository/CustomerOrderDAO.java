package com.example.fooddelivery.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.fooddelivery.model.CustomerOrder;

public interface CustomerOrderDAO extends JpaRepository<CustomerOrder, Integer>{

}
