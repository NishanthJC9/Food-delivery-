package com.example.fooddelivery.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.fooddelivery.dto.RestaurantDTO;
import com.example.fooddelivery.model.Restaurant;
import com.example.fooddelivery.repository.RestaurantDAO;

@Service
public class RestaurantService {

	@Autowired
	RestaurantDAO dao;
	
	public String createRestaurant(RestaurantDTO dto) {
		Restaurant rs = new Restaurant();
		rs.setRestaurantid(dto.getRestaurantid());
		rs.setRestaurantname(dto.getRestaurantname());
		rs.setRestaurantphone(dto.getRestaurantphone());
		rs.setRestaurantemail(dto.getRestaurantemail());
		rs.setRestaurantaddress(dto.getRestaurantaddress());
		dao.save(rs);
		return "Restaurant Details Created Successfully";
	}
	
	public List<Restaurant> getAllRestaurant(){
		return dao.findAll();
	}
	
	public Optional<Restaurant> getById(int resid){
		return dao.findById(resid);
	}
	
	public String deleteById(int resid){
		Optional<Restaurant> res = dao.findById(resid);
		if(res.isPresent()) {
			dao.deleteById(resid);
			return "Restaurant Details Deleted Successfully";	
		}
		return "Restaurant id not found";
	}
	
	public String updateRestaurant(RestaurantDTO dt,int resid) {
			
			Optional<Restaurant> or = dao.findById(resid);
			
			if(or.isEmpty()) {
				return "data not found";
			}
			
			else {
				
			Restaurant res  = or.get();
			res.setRestaurantname(dt.getRestaurantname());
			res.setRestaurantphone(dt.getRestaurantphone());
			res.setRestaurantemail(dt.getRestaurantemail());
			res.setRestaurantaddress(dt.getRestaurantaddress());
			dao.save(res);
			
			return "Restaurant Details Updated Successfully";
			}
		}
}
