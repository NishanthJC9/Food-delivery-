package com.example.fooddelivery.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class UserDTO {

	private int userId;
	
	@NotNull(message = "UserName should not be null")
	@Size(min = 2, max = 20, message = "UserName must be between 2 to 20 characters")
	private String username;
	
	@NotNull(message = "Password should not be null")
	@Size(min = 8, max = 12, message = "Password must be between 8 to 12 characters")
	private String password;
	
	@NotNull(message = "Email should not be null")
	@Email(message = "Invaild Email format")
	private String email;
	
	@NotNull(message = "Phone should not be null")
	@Size(min = 10, max = 12, message = "Phone must be 10 characters")
	private String phone;
	
	@NotNull(message = "Address should not be null")
	private String address;
	
	
	public UserDTO(int userId, String username, String password, String email, String phone, String address) {
		super();
		this.userId = userId;
		this.username = username;
		this.password = password;
		this.email = email;
		this.phone = phone;
		this.address = address;
	}


	public UserDTO() {
		super();
	}


	public int getUserId() {
		return userId;
	}


	public void setUserId(int userId) {
		this.userId = userId;
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPhone() {
		return phone;
	}


	public void setPhone(String phone) {
		this.phone = phone;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	@Override
	public String toString() {
		return "UserDTO [userId=" + userId + ", username=" + username + ", password=" + password + ", email=" + email
				+ ", phone=" + phone + ", address=" + address + "]";
	}
	
	
	
}
