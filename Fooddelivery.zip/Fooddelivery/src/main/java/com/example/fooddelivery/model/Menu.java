package com.example.fooddelivery.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Menu {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int menuid;
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="restaurantid")
	private Restaurant restaurant;
	private String itemname;
	private String description;
	private int price;
	
	
	public Menu(int menuid, Restaurant restaurant, String itemname, String description, int price) {
		super();
		this.menuid = menuid;
		this.restaurant = restaurant;
		this.itemname = itemname;
		this.description = description;
		this.price = price;
	}


	public Menu() {
		super();
	}


	public int getMenuid() {
		return menuid;
	}


	public void setMenuid(int menuid) {
		this.menuid = menuid;
	}


	public Restaurant getRestaurant() {
		return restaurant;
	}


	public void setRestaurant(Restaurant restaurant) {
		this.restaurant = restaurant;
	}


	public String getItemname() {
		return itemname;
	}


	public void setItemname(String itemname) {
		this.itemname = itemname;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public int getPrice() {
		return price;
	}


	public void setPrice(int price) {
		this.price = price;
	}


	@Override
	public String toString() {
		return "Menu [menuid=" + menuid + ", restaurant=" + restaurant + ", itemname=" + itemname + ", description="
				+ description + ", price=" + price + "]";
	}
	
	
	
}
