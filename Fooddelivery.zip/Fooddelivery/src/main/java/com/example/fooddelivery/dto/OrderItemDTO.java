package com.example.fooddelivery.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public class OrderItemDTO {

	private int orderitemid;
	
	@NotNull(message = "Quantity should not be null")
	@Min(value = 1, message = "Price should be greaterthan 1")
	@Max(value = 10, message = "Price Should be lessthan 10")
	private int quantity;
	private int orderid;
	private int menuid;
	
	public OrderItemDTO(int orderitemid, int quantity, int orderid, int menuid) {
		super();
		this.orderitemid = orderitemid;
		this.quantity = quantity;
		this.orderid = orderid;
		this.menuid = menuid;
	}

	public OrderItemDTO() {
		super();
	}

	public int getOrderitemid() {
		return orderitemid;
	}

	public void setOrderitemid(int orderitemid) {
		this.orderitemid = orderitemid;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getOrderid() {
		return orderid;
	}

	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}

	public int getMenuid() {
		return menuid;
	}

	public void setMenuid(int menuid) {
		this.menuid = menuid;
	}

	@Override
	public String toString() {
		return "OrderItemDTO [orderitemid=" + orderitemid + ", quantity=" + quantity + ", orderid=" + orderid
				+ ", menuid=" + menuid + "]";
	}

	
}
