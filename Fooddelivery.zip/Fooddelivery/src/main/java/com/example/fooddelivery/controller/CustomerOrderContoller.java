package com.example.fooddelivery.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.fooddelivery.dto.CustomerOrderDTO;
import com.example.fooddelivery.exceptionhandling.MyDeleteException;
import com.example.fooddelivery.exceptionhandling.MyUserexception;
import com.example.fooddelivery.model.CustomerOrder;
import com.example.fooddelivery.service.CustomerOrderService;

import jakarta.validation.Valid;

@RestController
@Validated
public class CustomerOrderContoller {

	@Autowired
	CustomerOrderService service;
	
	
	@PostMapping("/createOrder")
	public String createOrder(@Valid @RequestBody CustomerOrderDTO dto) {
		return service.createOrder(dto);
	}
	
	@GetMapping("/getallOrders")
	public List<CustomerOrder> getAllOrders(){
		return service.getAllOrders();
	}
	
	@GetMapping("/getbyorderid/{orderid}")
	public Optional<CustomerOrder> getById(@PathVariable int orderid) throws MyUserexception{
		if (orderid == 0) {
			throw new MyUserexception("orderid should be greater than Zero(0)");	
		}
		return service.getById(orderid);
	}
	
	@DeleteMapping("/deleteorder/{orderid}")
	public String deleteById(@PathVariable int orderid) throws MyDeleteException {
		if (orderid == 0) {
			throw new MyDeleteException("To delete Order orderid should be greater than Zero(0)");	
		}
		return service.deleteById(orderid);
	}
	
	@PutMapping("/updateorder/{orderid}")
	public String updateOrder(@Valid @RequestBody CustomerOrderDTO dt, @PathVariable int orderid) {
		return service.updateOrder(dt,orderid);
	}
}
