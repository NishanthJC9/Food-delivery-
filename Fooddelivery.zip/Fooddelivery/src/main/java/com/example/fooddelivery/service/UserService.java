package com.example.fooddelivery.service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.fooddelivery.dto.UserDTO;
import com.example.fooddelivery.model.User;
import com.example.fooddelivery.repository.UserDAO;


@Service
public class UserService {

	@Autowired
	UserDAO dao;
	
	public String createUser(UserDTO dto) {
		User ur = new User();
		ur.setUserId(dto.getUserId());
		ur.setUsername(dto.getUsername());
		ur.setPassword(dto.getPassword());
		ur.setEmail(dto.getEmail());
		ur.setPhone(dto.getPhone());
		ur.setAddress(dto.getAddress());
		dao.save(ur);
		return "User Details Created Successfully";
	}
	
	public List<User> getAllUser(){
		List<User> list = dao.findAll();
		Collections.sort(list);
		return list;
	}
	
	public Optional<User> getById(int userid){
		return dao.findById(userid);
	}
	
	public String deleteById(int userid){
		Optional<User> user = dao.findById(userid);
		if(user.isPresent()) {
			dao.deleteById(userid);
			return "User Details Deleted Successfully";	
		}
		return "User id not found";
	}
	
     public String updateUser(UserDTO dt,int userid) {
		
		Optional<User> ou = dao.findById(userid);
		
		if(ou.isEmpty()) {
			return "data not found";
		}
		
		else {
			
		User ur = ou.get();
			
		ur.setUsername(dt.getUsername());
		ur.setEmail(dt.getEmail());
		ur.setPassword(dt.getPassword());
		ur.setPhone(dt.getPhone());
		ur.setAddress(dt.getAddress());
		dao.save(ur);
		return "User Details Updated Successfully";
		}
	}
}
