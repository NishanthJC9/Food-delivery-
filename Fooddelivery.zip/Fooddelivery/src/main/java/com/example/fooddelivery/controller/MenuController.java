package com.example.fooddelivery.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.fooddelivery.dto.MenuDTO;
import com.example.fooddelivery.exceptionhandling.MyDeleteException;
import com.example.fooddelivery.exceptionhandling.MyUserexception;
import com.example.fooddelivery.model.Menu;
import com.example.fooddelivery.service.MenuService;

import jakarta.validation.Valid;



@RestController
@Validated
public class MenuController {

	@Autowired
	MenuService service;
	
	@PostMapping("/createMenu")
	public String createMenu(@Valid  @RequestBody MenuDTO dto) {
		return service.createMenu(dto);
	}
	
	@GetMapping("/getallMenu")
	public List<Menu> getAllMenu(){
		return service.getAllMenu();
	}
	
	@GetMapping("/getbymenuid/{menuid}")
	public Optional<Menu> getById(@PathVariable int menuid) throws MyUserexception{
		if (menuid == 0) {
			throw new MyUserexception("menuid should be greater than Zero(0)");	
		}
		return service.getById(menuid);
	}
	
	@DeleteMapping("/deletemenu/{menuid}")
	public String deleteById(@PathVariable int menuid) throws MyDeleteException {
		if (menuid == 0) {
			throw new MyDeleteException("To delete User userid should be greater than Zero(0)");	
		}
		return service.deleteById(menuid);
	}
	
	@PutMapping("/updatemenu/{menuid}")
	public String updateRestaurant(@Valid @RequestBody MenuDTO dt, @PathVariable int menuid) {
		return service.updateMenu(dt,menuid);
	}
}
