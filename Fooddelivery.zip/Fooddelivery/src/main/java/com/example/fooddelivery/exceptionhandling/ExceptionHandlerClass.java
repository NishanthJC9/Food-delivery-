package com.example.fooddelivery.exceptionhandling;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;


@ControllerAdvice
public class ExceptionHandlerClass {

	@ExceptionHandler(MyUserexception.class)
	public ResponseEntity<String> handleMyUserException(MyUserexception u){
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(u.getMessage());
	}
	
	@ExceptionHandler(MyDeleteException.class)
	public ResponseEntity<String> handleMyDeleteException(MyDeleteException d){
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(d.getMessage());
	}
}
