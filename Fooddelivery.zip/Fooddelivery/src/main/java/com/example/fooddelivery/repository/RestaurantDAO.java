package com.example.fooddelivery.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.fooddelivery.model.Restaurant;

public interface RestaurantDAO extends JpaRepository<Restaurant, Integer> {

}
