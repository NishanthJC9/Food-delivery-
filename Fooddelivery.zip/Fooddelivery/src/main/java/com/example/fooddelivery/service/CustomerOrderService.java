package com.example.fooddelivery.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.fooddelivery.dto.CustomerOrderDTO;
import com.example.fooddelivery.model.CustomerOrder;
import com.example.fooddelivery.model.Restaurant;
import com.example.fooddelivery.model.User;
import com.example.fooddelivery.repository.CustomerOrderDAO;
import com.example.fooddelivery.repository.RestaurantDAO;
import com.example.fooddelivery.repository.UserDAO;

@Service
public class CustomerOrderService {

	@Autowired
	CustomerOrderDAO cdao;
	
	@Autowired
	UserDAO udao;
	
	@Autowired
	RestaurantDAO rdao;
	
	public String createOrder(CustomerOrderDTO dto) {
		
		CustomerOrder cstord= convrtDtoToEntity(dto);
		
		
		cdao.save(cstord);
		return "Customer Order Details Created Successfully";
	}
	
	private CustomerOrder convrtDtoToEntity(CustomerOrderDTO dto) {
		
		CustomerOrder csor = new CustomerOrder();
		csor.setOrderid(dto.getOrderid());
		csor.setStatus(dto.getStatus());
		csor.setOrderdate(dto.getOrderdate());
		
		Optional<User> us = udao.findById(dto.getUserid());
		if(us.isPresent()) {
			csor.setUser(us.get());
		}
		
		Optional<Restaurant>  res=rdao.findById(dto.getRestaurantid());
		  if(res.isPresent()) {
			  csor.setRestaurant(res.get());
		  }
		      
		return csor;
		
	}
	
	public List<CustomerOrder> getAllOrders(){
		return cdao.findAll();
	}
	
	public Optional<CustomerOrder> getById(int orderid){
		return cdao.findById(orderid);
	}
	
	public String deleteById(int orderid){
		cdao.deleteById(orderid);
		return "Order Deleted Successfully";
	}
	
	public String updateOrder(CustomerOrderDTO dt,int orderid) {
		
		Optional<CustomerOrder> oc = cdao.findById(orderid);
		
		if(oc.isEmpty()) {
			return "data not found";
		}
		
		else {
			
		CustomerOrder csor = oc.get();
			
		csor.setStatus(dt.getStatus());
		csor.setOrderdate(new Date());
		
		cdao.save(csor);
		return "Customer Order Details Updated Successfully";
		}
	}
	
	
}
