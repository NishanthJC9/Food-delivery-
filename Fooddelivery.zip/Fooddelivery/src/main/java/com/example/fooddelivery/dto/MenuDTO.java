package com.example.fooddelivery.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class MenuDTO {

	private int menuid;
	private int restaurantid;
	
	@NotNull(message = "Item Name should not be null")
	@Size(min = 2, max = 20, message = "Item Name must be between 2 to 20 characters")
	private String itemname;
	
	@NotNull(message = "Description should not be null")
	@Size(min = 2, max = 15, message = "Description must be between 2 to 15 characters")
	private String description;
	
	@NotNull(message = "Price should not be null")
	@Min(value = 10, message = "Price should be greaterthan 10")
	@Max(value = 1000, message = "Price Should be lessthan 1000")
	private int price;
	
	
	public MenuDTO(int menuid, int restaurantid, String itemname, String description, int price) {
		super();
		this.menuid = menuid;
		this.restaurantid = restaurantid;
		this.itemname = itemname;
		this.description = description;
		this.price = price;
	}


	public MenuDTO() {
		super();
	}


	public int getMenuid() {
		return menuid;
	}


	public void setMenuid(int menuid) {
		this.menuid = menuid;
	}


	public int getRestaurantid() {
		return restaurantid;
	}


	public void setRestaurantid(int restaurantid) {
		this.restaurantid = restaurantid;
	}


	public String getItemname() {
		return itemname;
	}


	public void setItemname(String itemname) {
		this.itemname = itemname;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public int getPrice() {
		return price;
	}


	public void setPrice(int price) {
		this.price = price;
	}


	@Override
	public String toString() {
		return "MenuDTO [menuid=" + menuid + ", restaurantid=" + restaurantid + ", itemname=" + itemname
				+ ", description=" + description + ", price=" + price + "]";
	}
	
	
	
}
