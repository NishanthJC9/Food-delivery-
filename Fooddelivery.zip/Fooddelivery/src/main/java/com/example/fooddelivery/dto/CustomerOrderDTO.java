package com.example.fooddelivery.dto;

import java.util.Date;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class CustomerOrderDTO {

	private int orderid;
	private Date orderdate;
	
	@NotNull(message = "Status should not be null")
	@Size(min = 2, max = 15, message = "Status must be between 2 to 15 characters")
	private String status;
	private int userid;
	private int restaurantid;
	
	public CustomerOrderDTO(int orderid, Date orderdate, String status, int userid, int restaurantid) {
		
		this.orderid = orderid;
		this.orderdate = orderdate;
		this.status = status;
		this.userid = userid;
		this.restaurantid = restaurantid;
	}

	public CustomerOrderDTO() {
		this.orderdate= new Date();
	}

	public int getOrderid() {
		return orderid;
	}

	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}

	public Date getOrderdate() {
		return orderdate;
	}

	public void setOrderdate(Date orderdate) {
		this.orderdate = orderdate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public int getRestaurantid() {
		return restaurantid;
	}

	public void setRestaurantid(int restaurantid) {
		this.restaurantid = restaurantid;
	}

	@Override
	public String toString() {
		return "CustomerOrderDTO [orderid=" + orderid + ", orderdate=" + orderdate + ", status=" + status + ", userid="
				+ userid + ", restaurantid=" + restaurantid + "]";
	}
	
	
	
	
}
