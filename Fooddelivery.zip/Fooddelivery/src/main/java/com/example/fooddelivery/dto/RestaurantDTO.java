package com.example.fooddelivery.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class RestaurantDTO {

	private int restaurantid;
	
	@NotNull(message = "RestaurantName should not be null")
	@Size(min = 2, max = 20, message = "RestaurantName must be between 2 to 20 characters")
	private String restaurantname;
	
	@NotNull(message = "RestaurantEmail should not be null")
	@Email(message = "Invaild Email format")
	private String restaurantemail;
	
	@NotNull(message = "RestaurantPhone should not be null")
	@Size(min = 10, max = 12, message = "Phone must be 10 characters")
	private String restaurantphone;
	
	@NotNull(message = "RestaurantAddress should not be null")
	private String restaurantaddress;
	
	
	public RestaurantDTO(int restaurantid, String restaurantname, String restaurantemail, String restaurantphone,
			String restaurantaddress) {
		super();
		this.restaurantid = restaurantid;
		this.restaurantname = restaurantname;
		this.restaurantemail = restaurantemail;
		this.restaurantphone = restaurantphone;
		this.restaurantaddress = restaurantaddress;
	}


	public RestaurantDTO() {
		super();
	}


	public int getRestaurantid() {
		return restaurantid;
	}


	public void setRestaurantid(int restaurantid) {
		this.restaurantid = restaurantid;
	}


	public String getRestaurantname() {
		return restaurantname;
	}


	public void setRestaurantname(String restaurantname) {
		this.restaurantname = restaurantname;
	}


	public String getRestaurantemail() {
		return restaurantemail;
	}


	public void setRestaurantemail(String restaurantemail) {
		this.restaurantemail = restaurantemail;
	}


	public String getRestaurantphone() {
		return restaurantphone;
	}


	public void setRestaurantphone(String restaurantphone) {
		this.restaurantphone = restaurantphone;
	}


	public String getRestaurantaddress() {
		return restaurantaddress;
	}


	public void setRestaurantaddress(String restaurantaddress) {
		this.restaurantaddress = restaurantaddress;
	}


	@Override
	public String toString() {
		return "RestaurantDTO [restaurantid=" + restaurantid + ", restaurantname=" + restaurantname
				+ ", restaurantemail=" + restaurantemail + ", restaurantphone=" + restaurantphone
				+ ", restaurantaddress=" + restaurantaddress + "]";
	}
	
	
	
}
