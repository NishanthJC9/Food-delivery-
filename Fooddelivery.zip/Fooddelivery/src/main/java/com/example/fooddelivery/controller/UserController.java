package com.example.fooddelivery.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.fooddelivery.dto.UserDTO;
import com.example.fooddelivery.exceptionhandling.MyDeleteException;
import com.example.fooddelivery.exceptionhandling.MyUserexception;
import com.example.fooddelivery.model.User;
import com.example.fooddelivery.service.UserService;

import jakarta.validation.Valid;


@RestController
@Validated
public class UserController {

	@Autowired
	UserService service;
	
	@PostMapping("/createuser")
	public String createUser(@Valid @RequestBody UserDTO dto) {
		return service.createUser(dto);
	}
	
	@GetMapping("/getalluser")
	public List<User> getAllUser(){
		return service.getAllUser();
	}
	
	@GetMapping("/getbyuserid/{userid}")
	public Optional<User> getById(@PathVariable int userid) throws MyUserexception{
		if (userid == 0) {
			throw new MyUserexception("userid should be greater than Zero(0)");	
		}
		return service.getById(userid);
	}
	
	@DeleteMapping("/deleteuser/{userid}")
	public String deleteById(@PathVariable int userid) throws MyDeleteException{
		if (userid == 0) {
			throw new MyDeleteException("To delete User userid should be greater than Zero(0)");	
		}
		return service.deleteById(userid);
	}
	
	@PutMapping("/updateuser/{userid}")
	public String updateUser(@Valid @RequestBody UserDTO dt, @PathVariable int userid) {
		return service.updateUser(dt,userid);
	}
	
}
