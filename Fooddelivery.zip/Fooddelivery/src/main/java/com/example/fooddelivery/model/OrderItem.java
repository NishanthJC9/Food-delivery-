package com.example.fooddelivery.model;


import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class OrderItem {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int orderitemid;
	
	private int quantity;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "orderid", referencedColumnName = "orderid")
	private CustomerOrder customerorder;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "menuid", referencedColumnName = "menuid")
	private Menu menu;

	public OrderItem(int orderitemid, int quantity, CustomerOrder customerorder, Menu menu) {
		super();
		this.orderitemid = orderitemid;
		this.quantity = quantity;
		this.customerorder = customerorder;
		this.menu = menu;
	}

	public OrderItem() {
		super();
	}

	public int getOrderitemid() {
		return orderitemid;
	}

	public void setOrderitemid(int orderitemid) {
		this.orderitemid = orderitemid;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public CustomerOrder getCustomerorder() {
		return customerorder;
	}

	public void setCustomerorder(CustomerOrder customerorder) {
		this.customerorder = customerorder;
	}

	public Menu getMenu() {
		return menu;
	}

	public void setMenu(Menu menu) {
		this.menu = menu;
	}

	@Override
	public String toString() {
		return "OrderItem [orderitemid=" + orderitemid + ", quantity=" + quantity + ", customerorder=" + customerorder
				+ ", menu=" + menu + "]";
	}
	
	
}
