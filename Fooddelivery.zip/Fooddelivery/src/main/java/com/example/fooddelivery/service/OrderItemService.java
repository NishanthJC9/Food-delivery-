package com.example.fooddelivery.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.fooddelivery.dto.OrderItemDTO;
import com.example.fooddelivery.model.CustomerOrder;
import com.example.fooddelivery.model.Menu;
import com.example.fooddelivery.model.OrderItem;
import com.example.fooddelivery.repository.CustomerOrderDAO;
import com.example.fooddelivery.repository.MenuDAO;
import com.example.fooddelivery.repository.OrderItemDAO;

@Service
public class OrderItemService {

	@Autowired
	OrderItemDAO dao;
	
	@Autowired
	CustomerOrderDAO cdao;
	
	@Autowired
	MenuDAO mdao;
	
	public String createOderItem(OrderItemDTO dto) {
		
		OrderItem orit= convrtDtoToEntity(dto);
		
		
		dao.save(orit);
		return "Order Item Details Created Successfully";
	}
	
	private OrderItem convrtDtoToEntity(OrderItemDTO dto) {
		
		OrderItem orim = new OrderItem();
		orim.setOrderitemid(dto.getOrderitemid());
		orim.setQuantity(dto.getQuantity());
		
		Optional<CustomerOrder> co = cdao.findById(dto.getOrderid());
		if(co.isPresent()) {
			orim.setCustomerorder(co.get());
		}
		
		Optional<Menu>  menu=mdao.findById(dto.getMenuid());
		  if(menu.isPresent()) {
			  orim.setMenu(menu.get());
		  }
		      
		return orim;
		
	}
	
	public List<OrderItem> getAllOrderItems(){
		return dao.findAll();
	}
	
	public Optional<OrderItem> getById(int orderitemid){
		return dao.findById(orderitemid);
	}
	
	public String deleteById(int orderitemid){
		Optional<OrderItem> oritem = dao.findById(orderitemid);
		if(oritem.isPresent()) {
			dao.deleteById(orderitemid);
			return "OrderItem Deleted Successfully";	
		}
		return "OrderItem not found";
	}
	
	public String updateOrderItem(OrderItemDTO dt,int orderitemid) {
		
		Optional<OrderItem> or = dao.findById(orderitemid);
		
		if(or.isEmpty()) {
			return "data not found";
		}
		
		else {
			
		OrderItem orim = or.get();
			
		orim.setQuantity(dt.getQuantity());
		dao.save(orim);
		return "Order Item Details Updated Successfully";
		}
	}
}
