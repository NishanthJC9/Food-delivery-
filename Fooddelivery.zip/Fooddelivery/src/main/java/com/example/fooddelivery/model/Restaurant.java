package com.example.fooddelivery.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Restaurant implements Comparable<Restaurant> {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int restaurantid;
	private String restaurantname;
	private String restaurantemail;
	private String restaurantphone;
	private String restaurantaddress;
	
// Parameterized constructor	
	public Restaurant(int restaurantid, String restaurantname, String restaurantemail, String restaurantphone,
			String restaurantaddress) {
		super();
		this.restaurantid = restaurantid;
		this.restaurantname = restaurantname;
		this.restaurantemail = restaurantemail;
		this.restaurantphone = restaurantphone;
		this.restaurantaddress = restaurantaddress;
	}

// non Parameterized Constructor
	public Restaurant() {
		super();
	}

// using compareable interface for sorting
		@Override
		public int compareTo(Restaurant other) {
			
			// only by the username
			// return this.username.compareTo(other.username);
			// Compare by username first
			int restaurantnameComparison = this.restaurantname.compareTo(other.restaurantname);
			if (restaurantnameComparison != 0) {
				return restaurantnameComparison;
			}
			// If usernames are equal, compare by user_id
			return Integer.compare(this.restaurantid, other.restaurantid);
		}
		
// getters and setters
	public int getRestaurantid() {
		return restaurantid;
	}


	public void setRestaurantid(int restaurantid) {
		this.restaurantid = restaurantid;
	}


	public String getRestaurantname() {
		return restaurantname;
	}


	public void setRestaurantname(String restaurantname) {
		this.restaurantname = restaurantname;
	}


	public String getRestaurantemail() {
		return restaurantemail;
	}


	public void setRestaurantemail(String restaurantemail) {
		this.restaurantemail = restaurantemail;
	}


	public String getRestaurantphone() {
		return restaurantphone;
	}


	public void setRestaurantphone(String restaurantphone) {
		this.restaurantphone = restaurantphone;
	}


	public String getRestaurantaddress() {
		return restaurantaddress;
	}


	public void setRestaurantaddress(String restaurantaddress) {
		this.restaurantaddress = restaurantaddress;
	}

// toString
	@Override
	public String toString() {
		return "Restaurant [restaurantid=" + restaurantid + ", restaurantname=" + restaurantname + ", restaurantemail="
				+ restaurantemail + ", restaurantphone=" + restaurantphone + ", restaurantaddress=" + restaurantaddress
				+ "]";
	}

	
	
}
