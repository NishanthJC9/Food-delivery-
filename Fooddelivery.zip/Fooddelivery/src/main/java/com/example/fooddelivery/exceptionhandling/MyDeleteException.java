package com.example.fooddelivery.exceptionhandling;

public class MyDeleteException extends Exception{

	public MyDeleteException(String message) {
		super(message);
	}

	
}
