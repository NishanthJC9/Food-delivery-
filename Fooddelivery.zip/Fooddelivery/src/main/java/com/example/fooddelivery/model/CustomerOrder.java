package com.example.fooddelivery.model;

import java.util.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
public class CustomerOrder {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int orderid;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date orderdate;
	
	private String status;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "userid", referencedColumnName = "userid")
	private User user;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "restaurantid", referencedColumnName = "restaurantid")
	private Restaurant restaurant;

	public CustomerOrder(int orderid, Date orderdate, String status, User user, Restaurant restaurant) {
		super();
		this.orderid = orderid;
		this.orderdate = orderdate;
		this.status = status;
		this.user = user;
		this.restaurant = restaurant;
	}

	public CustomerOrder() {
		this.orderdate = new Date();
	}

	public int getOrderid() {
		return orderid;
	}

	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}

	public Date getOrderdate() {
		return orderdate;
	}

	public void setOrderdate(Date orderdate) {
		this.orderdate = orderdate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Restaurant getRestaurant() {
		return restaurant;
	}

	public void setRestaurant(Restaurant restaurant) {
		this.restaurant = restaurant;
	}

	@Override
	public String toString() {
		return "CustomerOrder [orderid=" + orderid + ", orderdate=" + orderdate + ", status=" + status + ", user="
				+ user + ", restaurant=" + restaurant + "]";
	}

	
	
}
