package com.example.fooddelivery.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.fooddelivery.dto.OrderItemDTO;
import com.example.fooddelivery.exceptionhandling.MyDeleteException;
import com.example.fooddelivery.exceptionhandling.MyUserexception;
import com.example.fooddelivery.model.OrderItem;
import com.example.fooddelivery.service.OrderItemService;

import jakarta.validation.Valid;

@RestController
@Validated
public class OrderItemController {

	@Autowired
	OrderItemService service;
	
	@PostMapping("/createOrderItem")
	public String createOrderItem(@Valid @RequestBody OrderItemDTO dto) {
		return service.createOderItem(dto);
	}
	
	@GetMapping("/getallOrderItems")
	public List<OrderItem> getAllOrderItems(){
		return service.getAllOrderItems();
	}
	
	@GetMapping("/getbyorderid/{orderitemid}")
	public Optional<OrderItem> getById(@PathVariable int orderitemid) throws MyUserexception{
		if (orderitemid == 0) {
			throw new MyUserexception("orderitemid should be greater than Zero(0)");	
		}
		return service.getById(orderitemid);
	}
	
	@DeleteMapping("/deleteorderitem/{orderitemid}")
	public String deleteById(@PathVariable int orderitemid) throws MyDeleteException {
		if (orderitemid == 0) {
			throw new MyDeleteException("To delete OrderItem orderitemid should be greater than Zero(0)");	
		}
		return service.deleteById(orderitemid);
	}
	
	@PutMapping("/updateorderitem/{orderitemid}")
	public String updateOrderItem(@Valid @RequestBody OrderItemDTO dt, @PathVariable int orderitemid ) {
		return service.updateOrderItem(dt,orderitemid);
	}
	
}
