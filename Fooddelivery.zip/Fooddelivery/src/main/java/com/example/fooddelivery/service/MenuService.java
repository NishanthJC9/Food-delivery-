package com.example.fooddelivery.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.fooddelivery.dto.MenuDTO;
import com.example.fooddelivery.model.Menu;
import com.example.fooddelivery.model.Restaurant;
import com.example.fooddelivery.repository.MenuDAO;
import com.example.fooddelivery.repository.RestaurantDAO;

@Service
public class MenuService {

	@Autowired
	MenuDAO dao;
	
	@Autowired
	RestaurantDAO restDao;
	
	
	public String createMenu(MenuDTO dto) {
		
		Menu menu= convrtDtoToEntity(dto);
		
		
		dao.save(menu);
		return "Menu Details Created Successfully";
	}
	
	private Menu convrtDtoToEntity(MenuDTO dto) {
		
		Menu me = new Menu();
		me.setMenuid(dto.getMenuid());
		me.setItemname(dto.getItemname());
		me.setDescription(dto.getDescription());
		me.setPrice(dto.getPrice());
		
		Optional<Restaurant>  res=restDao.findById(dto.getRestaurantid());
		  if(res.isPresent()) {
			  me.setRestaurant(res.get());
		  }
		      
		
		return me;
		
	}

	public List<Menu> getAllMenu(){
		return dao.findAll();
	}
	
	public Optional<Menu> getById(int menuid){
		return dao.findById(menuid);
	}
	
	public String deleteById(int menuid){
		dao.deleteById(menuid);
		return "Menu Deleted Successfully";
	}
	
     public String updateMenu(MenuDTO dt,int menuid) {
		
		Optional<Menu> om = dao.findById(menuid);
		
		if(om.isEmpty()) {
			return "data not found";
		}
		
		else {
			
		Menu mu = om.get();
			
		mu.setItemname(dt.getItemname());
		
		mu.setDescription(dt.getDescription());
		mu.setPrice(dt.getPrice());
		dao.save(mu);
		return "Menu Details Updated Successfully";
		}
	}
}
