package com.example.fooddelivery.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.fooddelivery.dto.RestaurantDTO;
import com.example.fooddelivery.exceptionhandling.MyDeleteException;
import com.example.fooddelivery.exceptionhandling.MyUserexception;
import com.example.fooddelivery.model.Restaurant;
import com.example.fooddelivery.service.RestaurantService;

import jakarta.validation.Valid;

@RestController
@Validated
public class RestaurantController {

	@Autowired
	RestaurantService service;
	
	@PostMapping("/createRestaurant")
	public String createRestaurant(@Valid @RequestBody RestaurantDTO dto) {
		return service.createRestaurant(dto);
	}
	
	@GetMapping("/getallRestaurant")
	public List<Restaurant> getAllRestaurant(){
		return service.getAllRestaurant();
	}
	
	@GetMapping("/getbyidres/{resid}")
	public Optional<Restaurant> getById(@PathVariable int resid) throws MyUserexception{
		if (resid == 0) {
			throw new MyUserexception("restaurantid should be greater than Zero(0)");	
		}
		return service.getById(resid);
	}
	
	@DeleteMapping("/deleteres/{resid}")
	public String deleteById(@PathVariable int resid) throws MyDeleteException {
		if (resid == 0) {
			throw new MyDeleteException("To delete Restaurant restaurantid should be greater than Zero(0)");	
		}
		return service.deleteById(resid);
	}
	
	@PutMapping("/updateres/{resid}")
	public String updateRestaurant(@Valid @RequestBody RestaurantDTO dt, @PathVariable int resid) {
		return service.updateRestaurant(dt,resid);
	}
}
