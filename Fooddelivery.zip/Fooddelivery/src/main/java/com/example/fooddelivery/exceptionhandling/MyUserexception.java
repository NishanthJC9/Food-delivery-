package com.example.fooddelivery.exceptionhandling;

public class MyUserexception extends Exception {

	public MyUserexception(String message) {
		super(message);
	}

	
}
